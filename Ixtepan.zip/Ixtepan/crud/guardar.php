<?php
//mandamos a llamar la conexion de la bd
include("../conection/conex.php");

$conec = conectar();

//guardar los datos que se envian mediante el post

$NombreBien = $_POST['NombreBien'];
$descripcion = $_POST['Descripcion'];
$Marca = $_POST['Marca'];
$Precio = $_POST['Precio'];



$insertarInven = "INSERT INTO productos (nombre, descripcion, marca, precio)VALUES ('$NombreBien','$descripcion','$Marca','$Precio')";
 echo $insertarInven;
$queryInsert = mysqli_query($conec, $insertarInven);

if ($queryInsert) {
    echo '<script>location.href = "../index.php";</script> ';
}else{
    echo 'Error al insertar';
}
