<?php
include("../conection/conex.php");
//conexion de base de datos
$conn = conectar();
// Obtener el id del registro a actualizar
$id = $_GET['id'];


// Procesar los datos enviados por el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $Nombre = $_POST['Nombre'];
    $password = $_POST['Password'];

  

    // Ejecutar la consulta de actualización
    $sql = "UPDATE user SET  nombre='$Nombre', pass ='$password' WHERE idUser=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente.";
    } else {
        echo "Error al actualizar el registro: " . $conn->error;
    }
    $result = $conn->query($sql);
}


header('Location: ../Usuarios.php');


?>