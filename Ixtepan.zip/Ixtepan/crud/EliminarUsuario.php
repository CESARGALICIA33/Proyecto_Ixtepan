<?php
include("../conection/conex.php");
//conexion de base de datos
$conn = conectar();
$id;
//validar si se ha recibido un valor desde el get
if (!$_GET) {
    echo "No se ha enviado ningun parametro";
} else {
    $id = $_GET['id'];
}


// Obtener el id del departamento que se desea eliminar


// Actualizar el estatus de registro del departamento a 0
$queryDelete = "DELETE FROM user WHERE " . " idUser = $id";
echo $queryDelete;
$resultado = mysqli_query($conn, $queryDelete);

if (!$resultado) {
    echo 'Error al eliminar';
} else {
    echo '<script>location.href = "../usuarios.php";</script> ';
}
