<?php
include("../conection/conex.php");
//conexion de base de datos
$conn = conectar();

// Obtener el id del registro a actualizar
$id = $_GET['id'];
echo $id;

// Procesar los datos enviados por el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];

    // Ejecutar la consulta de actualización
    $sql = "UPDATE familias SET Nombre='$nombre', Descripcion='$descripcion' WHERE IdFamilia=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente.";
    } else {
        echo "Error al actualizar el registro: " . $conn->error;
    }
}


header('Location: ../Coordinacion.php');


?>