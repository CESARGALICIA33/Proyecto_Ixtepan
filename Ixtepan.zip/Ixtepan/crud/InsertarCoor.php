<?php
include("../conection/conex.php");
//conexion de base de datos
$conn = conectar();

// Obtener los demás valores del formulario y escaparlos para prevenir inyecciones SQL
$nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
$descripcion = mysqli_real_escape_string($conn, $_POST['descripcion']);

$insertarInven = "INSERT INTO familias (Nombre, Descripcion)VALUES ('$nombre','$descripcion')";
 echo $insertarInven;
$queryInsert = mysqli_query($conn, $insertarInven);

if ($queryInsert) {
    echo '<script>location.href = "../Coordinacion.php";</script> ';
}else{
    echo 'Error al insertar';
}


// Cerrar la conexión
mysqli_close($conn);
//header('Location: AgregarCoor.php');
?>