<?php
//mandamos a llamar la conexion de la bd
include("../conection/conex.php");
$id;
//validar si se ha recibido un valor desde el get
if (!$_GET) {
    echo "No se ha enviado ningun parametro";
} else {
    $id = $_GET['id'];
}

$conec = conectar();
$query = "SELECT * FROM productos WHERE idProductos = '$id';";
$queryInsert = mysqli_query($conec, $query);

$rows = $queryInsert->fetch_array();

//guardar los datos que se envian mediante el post
$NombreBien = $rows['nombre'];
$descripcion = $rows['descripcion'];
$marca = $rows['marca'];
$precio = $rows['precio'];


$insertarInven = "UPDATE productos set " . " nombre = '$NombreBien', descripcion = '$descripcion', marca = '$marca', precio = '$precio' WHERE IdProductos = '$id'"; 
$queryInsert = mysqli_query($conec, $insertarInven);

if ($queryInsert) {
    echo '<script>location.href = "../index.php";</script> ';
}else{
    echo 'Error al actualizar';
}