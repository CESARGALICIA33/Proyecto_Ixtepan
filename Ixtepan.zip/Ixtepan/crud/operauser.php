<?php
//mandamos a llamar la conexion de la bd
include("../conection/conex.php");

$conec = conectar();

//guardar los datos que se envian mediante el post

$NombreBien = $_POST['nomusuario'];
$descripcion = $_POST['Password'];



$insertarInven = "INSERT INTO user (nombre, pass)VALUES ('$NombreBien','$descripcion')";
$queryInsert = mysqli_query($conec, $insertarInven);

if ($queryInsert) {
    echo '<script>location.href = "../usuarios.php";</script> ';
}else{
    echo 'Error al insertar';
}
