-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-11-2023 a las 07:49:26
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ixtepan`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familias`
--

CREATE TABLE `familias` (
  `IdFamilia` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Descripcion` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `familias`
--

INSERT INTO `familias` (`IdFamilia`, `Nombre`, `Descripcion`) VALUES
(1, 'Cargadores', 'cargadores para diferentes equipos de computo.'),
(2, 'Teclados', 'Teclados para laptops, con diferentes distribuciones'),
(5, 'Baterias', 'Baterias para laptops, de diferentes marcas'),
(6, 'Cartuchos', 'Cartuchos de tinta de diferentes marcas y colores'),
(9, 'Pantallas', 'Pantallas para laptops de diferentes marcas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `idProductos` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `precio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`idProductos`, `nombre`, `descripcion`, `marca`, `precio`) VALUES
(2, 'Cargador HP mini', 'Cargador de 19.5v 4.0*1.7', 'HP', 420),
(3, 'Cargador ACER', 'Cargador de 19v3 5.5*1.7 Punt Azul', 'Acer', 450),
(4, 'Cargador Samsung', 'Cargador de 19v2 5.5*3.0', 'Samsung', 420),
(5, 'Cargador Dell', 'Cargador de 20v2 7.4*5.0', 'Dell', 550),
(6, 'Cargador Dell', 'Cargador Dell 19v3 5.5*2.5', 'Dell', 440),
(7, 'Teclado CQ40', 'Teclado HP compatible con XQ40, XQ41, DV4-1000', 'HP', 550),
(8, 'Teclado CQ42', 'Teclado compatible con CQ42 y G42', 'HP', 575),
(9, 'Teclado CQ56', 'Teclado compatible con CQ62, CQ56, G62, G56', 'HP', 560),
(10, 'BATERIA ACER 5635Z', '6 cells 11.1v 4400mAh compatible con Gateway As09c31 y Acer Extensa', 'Acer', 990),
(11, 'Bateria Acer 5500', '6 cells 10.8v 4400mAH, compatible con Aspire 5520, 5920, 6920, 7520', 'Acer', 990),
(12, 'Bateria Acer D270', '6 cells 11.1V 4400mAh, compatible con Acer Aspire One, D255, D260', 'Acer', 1140),
(13, 'EPS COM  TD631', 'CARTUCHO DE TINTA NEGRO', 'EPS COM', 120),
(14, 'EOS COM T60633', 'CARTUCHO DE TINTA COLOR CYAN', 'EPS COM', 120),
(15, 'EPS COM T1971', 'CARTUCHO UNIVERSAL DE TINTA NEGRA', 'EPS COM', 140),
(16, 'PANTALLA EARS', '8.9 led, compatible con HSD0891W1', 'Generica', 1200);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`idUser`, `nombre`, `pass`) VALUES
(1, 'Admin', 'admin'),
(2, 'Admin03', 'password');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `familias`
--
ALTER TABLE `familias`
  ADD PRIMARY KEY (`IdFamilia`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`idProductos`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `familias`
--
ALTER TABLE `familias`
  MODIFY `IdFamilia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `idProductos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
